<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/app.css',
        'resources/js/app.js'
    ]); ?>
</head>

<body class="min-h-screen flex flex-col">

<header class="px-10 h-15 bg-linear-to-r from-cyan-500 to-cyan-800 text-white flex items-center text-2xl justify-between gap-6 text-ellipsis">
    <?php echo $__env->make('includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</header>

<main class="flex-1 flex items-center justify-center py-6">
    <?php echo $__env->yieldContent('main'); ?>
</main>

<footer class="w-full flex px-10 py-4 flex-col bg-stone-400 text-white">
    <?php echo $__env->make('includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</footer>
</body>
</html>
<?php /**PATH D:\projects\yakovlev_pp01.project\resources\views/layouts/app.blade.php ENDPATH**/ ?>