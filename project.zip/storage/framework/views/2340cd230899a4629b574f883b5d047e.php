<?php $__env->startSection('title', 'Вход'); ?>

<?php $__env->startSection('main'); ?>
    <form action="<?php echo e(route('login')); ?>"
          method="POST"
          class="min-h-96 w-xl px-8 py-8 shadow-stone-500 shadow rounded-lg flex flex-col gap-3.5">
        <?php echo csrf_field(); ?>
        <h1 class="text-3xl">Вход</h1>


        <div>
            <label for="email" class="font-light">Почта</label>
            <input id="email"
                   name="email"
                   type="text"
                   class="w-full border border-stone-300 py-4 px-4 rounded-lg">
        </div>

        <div>
            <label for="password" class="font-light">Пароль</label>
            <input id="password"
                   name="password"
                   type="password"
                   class="w-full border border-stone-300 py-4 px-4 rounded-lg">
        </div>

        <div class="flex items-center justify-between">
            <button class="px-8 py-3.5 self-start bg-cyan-500 rounded-lg text-2xl text-white hover:bg-cyan-600 transition cursor-pointer"
                    type="submit">Войти</button>

            <p>У меня <a href="<?php echo e(route('register')); ?>" class="text-cyan-700 underline">нет учётной записи</a></p>
        </div>


        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-red-500 mt-2"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\yakovlev_pp01.project\resources\views\auth\login.blade.php ENDPATH**/ ?>