<p class="flex items-center"><?php echo $__env->yieldContent('title'); ?></p>

<?php if(auth()->guard()->check()): ?>
    <div class="relative group inline-block cursor-pointer active:cursor-grabbing">
        <div class="flex gap-6 hover:bg-stone-950/25 p-2 px-4 transition rounded-full">
            <p class="text-ellipsis overflow-hidden whitespace-nowrap"><?php echo e(auth()->user()->full_name); ?></p>
            <div class="w-8 h-8 rounded-full bg-cyan-950"></div>
        </div>

        <div class="absolute text-black top-full right-0 w-47 bg-stone-200 shadow/50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition duration-200 rounded-lg px-2">
            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="cursor-pointer active:cursor-grabbing">Выйти</button>
            </form>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\projects\yakovlev_pp01.project\resources\views/includes/header.blade.php ENDPATH**/ ?>