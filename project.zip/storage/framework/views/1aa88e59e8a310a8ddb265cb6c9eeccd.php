<?php $__env->startSection('title', 'Создание'); ?>

<?php $__env->startSection('main'); ?>
    <form action="<?php echo e(route('tasks.store')); ?>"
          method="POST"
          class="min-h-96 my-20 w-xl px-8 py-8 shadow-stone-500 shadow rounded-lg flex flex-col gap-3.5">
        <?php echo csrf_field(); ?>
        <h1 class="text-3xl">Создание задачи</h1>

        <div>
            <label for="title" class="font-light">Наименование задачи</label>
            <input id="title"
                   name="title"
                   type="text"
                   class="w-full border border-stone-300 py-4 px-4 rounded-lg">
        </div>

        <div>
            <label for="description" class="font-light">Описание задачи</label>
            <textarea id="description"
                      name="description"
                      type="text"
                      class="w-full border border-stone-300 py-4 px-4 rounded-lg">
            </textarea>
        </div>

        <div class="flex flex-row gap-4">
            <div class="w-1/2">
                <label for="end_date" class="font-light">Дата окончания</label>
                <input id="end_date"
                       name="end_date"
                       type="date"
                       class="w-full border border-stone-300 py-4 px-4 rounded-lg">
            </div>
        </div>

        <p>Важно: задача должна быть определена как минимум на следующий день относительно текущего дня</p>

        <div>
            <label for="project_id">Задача в проекте:</label>
            <select name="project_id"
                    id="project_id"
                    class="w-full border border-stone-300 py-3 px-4 rounded-lg">

                <option value="">Выберите проект</option>

                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($project->id); ?>"
                        <?php if(old('project_id') == $project->id): echo 'selected'; endif; ?>>
                        <?php echo e($project->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        </div>

        <div>
            <label for="employee_id">Задача закреплена за сотрудником</label>
            <select name="employee_id"
                   id="employee_id"
                   class="overflow-y-auto w-full border border-stone-300 py-3 px-4 rounded-lg">

                <option value="">Выберите сотрудника</option>

                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($employee->id); ?>"
                        <?php if(old('employee_id') == $employee->id): echo 'selected'; endif; ?>>
                        <?php echo e($employee->full_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="flex items-center justify-between">
            <button class="px-8 py-3.5 self-start bg-cyan-500 rounded-lg text-2xl text-white hover:bg-cyan-600 transition cursor-pointer"
                    type="submit">Создать</button>
        </div>


        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-red-500 mt-2"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\yakovlev_pp01.project\resources\views/tasks/create.blade.php ENDPATH**/ ?>